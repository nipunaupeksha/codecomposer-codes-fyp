#ifndef _TMS320_H
#define _TMS320_H
 
typedef unsigned int   uint;
typedef unsigned short ushort;  
#define PASS -1


  typedef short DATA;
  typedef long LDATA;
  #define ABSVAL abs
  #define SHIFT15 >>15
  #define SHIFT1  /2
  #define ROUND 0x400
  #define DIV2	>>1

#endif

